﻿param([string]$Users,$ID,$location)
$ErrorActionPreference ="SilentlyContinue"
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn
Import-Module ActiveDirectory

if ($Users)
{
[string]$FinalOutput=$null
#$FinalOutput=$Users+ "`r`n"
#$output = "SamAccountName;PrimarySmtpAddress;UserPrincipalName;LinkedMasterAccount;LitigationHoldEnabled;RetentionPolicy;RetainDeletedItemsFor;ArchiveDatabase;ArchiveWarningQuota;ArchiveQuota;GrantSendOnBehalfTo;IssueWarningQuota;UseDatabaseQuotaDefaults;ProhibitSendQuota;ProhibitSendReceiveQuota;FullAccessPermissions;CustomAttribute11"
#Write-Output $output|out-file ".\Reconciliation.csv"
$i=0
Set-ADServerSettings -ViewEntireForest:$true
[string]$output=$null
#write-host "Getting Mailbox list"
$mbxs = $Users.Split(";")
#$mbxs = Get-Mailbox -resultsize unlimited -OrganizationalUnit $OU | Select-Object Alias,SamAccountName,PrimarySmtpAddress,UserPrincipalName,LinkedMasterAccount,LitigationHoldEnabled,RetentionPolicy,RetainDeletedItemsFor,ArchiveDatabase,ArchiveWarningQuota,ArchiveQuota,GrantSendOnBehalfTo,IssueWarningQuota,UseDatabaseQuotaDefaults,ProhibitSendQuota,ProhibitSendReceiveQuota
$count= $mbxs.count
#write-host "Mailboxes to Analyze :" $count
#$mbxs
$mbxs|%{$i++#write-host $_$CurrentMBX =$null$CurrentMBX = get-mailbox $_#Write-Progress -Activity "Working $i/$count" -PercentComplete $($i/$count*100 ) -Status $_.PrimarySmtpAddress -ErrorAction SilentlyContinueif ($CurrentMBX -ne $null){[string]$output=$null        $output = $CurrentMBX.SamAccountName.tostring() + ";" +`                  $CurrentMBX.PrimarySmtpAddress.tostring() + ";" +`                  $CurrentMBX.UserPrincipalName.tostring() + ";"                  if ($CurrentMBX.LinkedMasterAccount)                  {                    $output += $CurrentMBX.LinkedMasterAccount.tostring() + ";"                  }                  else                  {                    $output += $null + ";"                  }                  if ($CurrentMBX.LitigationHoldEnabled)                  {                    $output += $CurrentMBX.LitigationHoldEnabled.tostring() + ";"                  }                  else                  {                    $output += $null + ";"                  } 
                  if ($CurrentMBX.RetentionPolicy)                  {                    $output += $CurrentMBX.RetentionPolicy.tostring() + ";"                  }                  else                  {                    $output += $null + ";"                  }                  
                  if ($CurrentMBX.RetainDeletedItemsFor)                  {                    $output += $CurrentMBX.RetainDeletedItemsFor.tostring() + ";"                  }                  else                  {                    $output += $null + ";"                  }
                  if ($CurrentMBX.ArchiveDatabase)                  {                    $output += $CurrentMBX.ArchiveDatabase.tostring() + ";"                  }                  else                  {                    $output += $null + ";"                  }
                  
                  if($CurrentMBX.ArchiveWarningQuota.isunlimited)
                    {
                        $output += "Unlimited" + ";"
                    }
                  else
                    {
                        $output += $CurrentMBX.ArchiveWarningQuota.value.tokb().tostring() + ";"
                    }   
                  if($CurrentMBX.ArchiveQuota.isunlimited)
                    {
                        $output += "Unlimited" + ";"
                    }
                  else
                    {
                        $output += $CurrentMBX.ArchiveQuota.value.tokb().tostring() + ";"
                    }              
                          
                  [string]$temp=$null
                  $CurrentMBX.GrantSendOnBehalfTo|%{
                  if ($temp -eq "")
                  {
                  $temp = $CurrentMBX.Name
                  }
                  else
                  {
                  $temp += "§" + $CurrentMBX.Name
                  }
                  }
                                    
                  $output += $temp + ";" +`
                  $CurrentMBX.UseDatabaseQuotaDefaults + ";"
                  if($CurrentMBX.IssueWarningQuota.isunlimited)
                    {
                        $output += "Unlimited" + ";"
                    }
                  else
                    {
                        $output += $CurrentMBX.IssueWarningQuota.value.tokb().tostring() + ";"
                    }     
                  if($CurrentMBX.ProhibitSendQuota.isunlimited)
                    {
                        $output += "Unlimited" + ";"
                    }
                  else
                    {
                        $output += $CurrentMBX.ProhibitSendQuota.value.tokb().tostring() + ";"
                    }   
                  if($CurrentMBX.ProhibitSendReceiveQuota.isunlimited)
                    {
                        $output += "Unlimited" + ";"
                    }
                  else
                    {
                        $output += $CurrentMBX.ProhibitSendReceiveQuota.value.tokb().tostring() + ";"
                    }   
                  

[string]$result=$null
#write-host "test" -ForegroundColor Cyan
$Permissions = $null
$Permissions = get-mailboxpermission -identity $CurrentMBX.UserPrincipalName |?{(!$_.IsInherited) -and (!$_.Deny) -and ($_.AccessRights[0].ToString() -like "*FullAccess*") -and ($_.user.ToString() -ne "NT AUTHORITY\SELF")}
$ADPermissions = $null
#Write-Host $CurrentMBX.LinkedMasterAccount
#$ADPermissions = get-Adpermission -identity $CurrentMBX.Alias | ?{(!$_.IsInherited) -and (!$_.Deny) -and $_.ExtendedRights -like "Send*" -and ($_.user.ToString() -ne "NT AUTHORITY\SELF") -and ($_.user.ToString() -ne $_.LinkedMasterAccount)}
Set-Location AD:
$ADPermissions = (get-acl $CurrentMBX.distinguishedName).Access | ?{$_.ActiveDirectoryRights -eq "ExtendedRight" -and ($_.objectType -eq "ab721a54-1e2f-11d0-9819-00aa0040529b") -and ($_.IsInherited -ne $true) -and ($_.IdentityReference -ne "NT AUTHORITY\SELF") -and ($_.IdentityReference -ne $CurrentMBX.linkedmasteraccount)}


#$Permissions
[string]$FullAccess=$null
$Permissions|%{
if($FullAccess -eq "")
{
    $FullAccess = $_.User.rawidentity.ToString()
}
else
{
    $FullAccess += "§" + $_.User.rawidentity.ToString()
}
}#End fe

#SendAs
[string]$SendAs=$null
$ADPermissions|%{
if($SendAs -eq "")
{
    $SendAs = $_.IdentityReference.Value.tostring()
}
else
{
    $SendAs += "§" + $_.IdentityReference.Value.tostring()
}
}#End fe

$output += $FullAccess
$output += ";" + $SendAs
$output += ";" + $CurrentMBX.CustomAttribute11
#Write-Output $output|out-file ".\Reconciliation.csv" -Append
if ($FinalOutput -eq "")
    {
        $FinalOutput = $output
    }
else
    {
        $FinalOutput += "`r`n" + $output
    }
}
}
#set-location $location
#$date = get-date -Format "yyyyMMdd_hhmmss"

#$File = $location +"\Logs\" + "Job" + $ID + "_" + $date +".csv"
#Write-Host "writing date into $File" -ForegroundColor Red
#$FinalOutput|out-file -FilePath $File
return $FinalOutput
}#if ($Users)

