param ([string]$OutputFile="Reconciliation_Batch.csv")
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn
Import-Module ActiveDirectory

if (!(test-path "LOG"))
{
    new-item -Path ".\LOG" -ItemType directory
}

if (!(test-path "ARCHIVE"))
{
    new-item -Path ".\ARCHIVE" -ItemType directory
}

function Add-Log([string]$TYPE,[string]$Text,[string]$LOGFile)
    {
        $outputLOG=$null
        $Date = get-date -Format "dd/MM/yyyy HH:mm:ss"
        $outputLOG= $date +"`t" + "[" + $TYPE + "]" + "`t" + $Text
        Write-Output $outputLOG|out-file -FilePath $LOGFile -Append

    }


function Add-Zip
{
     param([string]$zipfilename) 



     if(-not (test-path($zipfilename)))
     {
          set-content $zipfilename 
               ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
          (dir $zipfilename).IsReadOnly = $false    

     }

     $shellApplication = new-object -com shell.application
     $zipPackage = $shellApplication.NameSpace($zipfilename)
     

     foreach($file in $input) 
     { 
          $zipPackage.CopyHere($file.FullName)
          Start-sleep -milliseconds 500
     }
} 


#$ErrorActionPreference ="SilentlyContinue"
Set-ADServerSettings -ViewEntireForest:$true
$Location = (Get-Location).Path
#CONST
$MaxUsersPerBatch = 500
$MaxJobs = 20
#END CONST


$Start = get-date
$StartDate = get-date -Format "yyyyMMdd_HHmmss"
$LOGFile = ".\LOG\" + $StartDate + "_Logs.log"
$OutputFile = $startdate + $OutputFile

Add-Log -TYPE "INFO" -Text "Stopping Current Jobs if required" -LOGFile $LOGFile
Get-Job|Stop-Job
Add-Log -TYPE "INFO" -Text "Removing Current Jobs if required" -LOGFile $LOGFile
Get-Job|Remove-Job
Add-Log -TYPE "INFO" -Text "Export is starting" -LOGFile $LOGFile
write-host "Max Jobs :" $MaxJobs -ForegroundColor Green
Add-Log -TYPE "INFO" -Text "Max Jobs : $MaxJobs" -LOGFile $LOGFile
Write-Host "Max Users Per Batch :" $MaxUsersPerBatch -ForegroundColor Green
Add-Log -TYPE "INFO" -Text "Max Users Per Batch : $MaxUsersPerBatch" -LOGFile $LOGFile

Add-Log -TYPE "INFO" -Text "Starting to collect users in AD" -LOGFile $LOGFile
Write-Host "Collecting users in AD"
#$MBXS = get-aduser -ldapfilter "(&(mail=*)(!name=HealthMailbox*))" -prop samAccountName -ResultSetSize 300
$MBXS = get-aduser -ldapfilter "(&(mail=*)(!name=HealthMailbox*)(msExchHomeServerName=*))" -prop samAccountName
Add-Log -TYPE "INFO" -Text "Ending to collect users in AD" -LOGFile $LOGFile
$NbUsers = $MBXS.Count
Add-Log -TYPE "INFO" -Text "Nb of mailboxes to analyze: $NbUsers" -LOGFile $LOGFile


$output = "SamAccountName;PrimarySmtpAddress;UserPrincipalName;LinkedMasterAccount;LitigationHoldEnabled;RetentionPolicy;RetainDeletedItemsFor;ArchiveDatabase;ArchiveWarningQuota;ArchiveQuota;GrantSendOnBehalfTo;IssueWarningQuota;UseDatabaseQuotaDefaults;ProhibitSendQuota;ProhibitSendReceiveQuota;FullAccessPermissions;SendAsPermissions;CustomAttribute11"
Write-Output $output|Out-File -FilePath $OutputFile -Encoding utf8


$NecessaryJobs = $NbUsers/$MaxUsersPerBatch
if (!($NecessaryJobs -eq [math]::round($NbUsers/$MaxUsersPerBatch)))
    {
        $NecessaryJobs = [math]::round($NecessaryJobs)+1
    }
Add-Log -TYPE "INFO" -Text "$NecessaryJobs Jobs will be required" -LOGFile $LOGFile

$AllUsers=@{}

Add-Log -TYPE "INFO" -Text "Start to Assign job ID to Mailboxes" -LOGFile $LOGFile
$j=0
for ($i=0;$i -lt $NbUsers;$i++)
    {
        Write-Progress -Activity "Assigning job ID to Mailboxes" -PercentComplete $($i/$Nbusers*100) -Status "$i/$NbUsers"
        if ($j -lt $NecessaryJobs)
            {
                $j++
                $AllUsers.Add($MBXS[$i].samAccountName,$j)                
            }
        else
            {
                $j=1
                $AllUsers.Add($MBXS[$i].samAccountName,$j)
            }
    }
Add-Log -TYPE "INFO" -Text "Finish to Assign job ID to Mailboxes" -LOGFile $LOGFile

#$AllUsers
Add-Log -TYPE "INFO" -Text "Start to create Mailbox allotment" -LOGFile $LOGFile
$ALLJOBS=@()
for ($i=1;$i -le $NecessaryJobs;$i++)
{
    Write-Progress -Activity "Creating Mailboxes Allotment" -PercentComplete $($i/$NecessaryJobs*100) -Status "$i/$NecessaryJobs"

    $Parameter = $null        
    $Lot=$AllUsers.GetEnumerator()|?{$_.value -eq $i}
    $Parameter = $Lot.Name -join(";")
    #$Lot|%{$Parameter+=$_.Name + ";"}        
    #$Parameter = $Parameter -replace ".{1}$"

    $JOB = New-Object system.Object
    $JOB | add-member -membertype NoteProperty -name ID -value $i
    $JOB | add-member -membertype NoteProperty -name Users -value $Parameter
    
    $ALLJOBS += $JOB									
}
Add-Log -TYPE "INFO" -Text "Finish to create Mailbox allotment" -LOGFile $LOGFile

$CurrentJob=0
$CurrentPlannedJobs=0
$JobsProcessed=0
$StillJobsToRun = $NecessaryJobs
while ($StillJobsToRun -gt 0 -or $CurrentRunningJobs -gt 0 -or $CurrentCompletedJobs -gt 0)
{
    Write-Progress -Activity "Jobs execution" -PercentComplete $($JobsProcessed/$NecessaryJobs*100) -Status "$JobsProcessed/$NecessaryJobs Tasks executed. $MaxUsersPerBatch mailboxes analyzed per Task"
    $CurrentRunningJobs = (Get-Job | Where-Object {$_.state -eq "Running"}).count
    $CurrentCompletedJobs = (Get-Job | Where-Object {$_.state -eq "Completed"}).count

    if($CurrentPlannedJobs -lt $MaxJobs -and $StillJobsToRun -gt 0)
        {
            $jobid = $ALLJOBS[$CurrentJob].ID
            write-host "Adding a new job ID $jobid" -ForegroundColor Blue
            Add-Log -TYPE "INFO" -Text "Adding a new job ID: $jobid" -LOGFile $LOGFile
            start-job -name $jobid -filepath ".\Extract_Job.ps1" -argumentlist ($ALLJOBS[$CurrentJob].Users, $ALLJOBS[$CurrentJob].ID, $Location)|Out-Null
            $CurrentPlannedJobs++
            $CurrentJob++
            $StillJobsToRun--
        }  

    if($CurrentCompletedJobs)
        {            
            $JobsToReceive = Get-Job | Where-Object {$_.state -eq "Completed"}
            #write-host "Receiving a job: before for each"
            $JobsToReceive|%{
                    $temp = Receive-Job -Id $_.ID
                    $ExecTime = [math]::round(($_.PSEndTime-$_.PSBeginTime).Totalseconds)
                    $JobName = $_.Name
                    write-host "Receiving job ID: $JobName. Task execution time: $ExecTime seconds"  -ForegroundColor Green
                    Add-Log -TYPE "INFO" -Text "Receiving job ID: $JobName. Task execution time: $ExecTime seconds" -LOGFile $LOGFile
                    
                    #write-host $temp
                    
                    Write-Output $temp|Out-File -FilePath $OutputFile -Append -Encoding utf8
                    Remove-Job -Id $_.ID
                    $CurrentPlannedJobs--
                    $JobsProcessed++
                }
        }
        
    #Write-Host "Sleeping 1 sec"
    Start-Sleep 1
      
}

Add-Log -TYPE "INFO" -Text "Converting File to UTF8 NoBOM" -LOGFile $LOGFile
$MyFile = Get-Content $OutputFile
$Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
[System.IO.File]::WriteAllLines($OutputFile, $MyFile, $Utf8NoBomEncoding)

Add-Log -TYPE "INFO" -Text "Removing CR in the file" -LOGFile $LOGFile
(Get-Content $OutputFile -Raw).Replace("`r`n","`n") | Set-Content $OutputFile -Force

Add-Log -TYPE "INFO" -Text "Moving file to ARCHIVE folder" -LOGFile $LOGFile
Move-Item $OutputFile -Destination ".\ARCHIVE"



$End = get-date
$Total = [math]::round(($End - $Start).TotalMinutes)

Add-Log -TYPE "INFO" -Text "Overall Execution Time: $Total Minutes" -LOGFile $LOGFile